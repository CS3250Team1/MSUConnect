# MSUConnect
#### A Uni Social Application - ANDROID


### Instructions on Docker
1. ```docker build -t msuconnect .```
2. ```docker run --name msuconnect msuconnect```

#### Coding Resources
- [Koitlin](https://kotlinlang.org/)
- [MEAN Stack - Youtube Intro](https://www.youtube.com/watch?v=wtIvu085uU0)
  - [MongoDB - Database](https://www.mongodb.com/)
  - [ExpressJS - ](https://expressjs.com/)
  - [AngularJS - Web Frontend](https://angularjs.org/)
  - [NodeJS - ](https://nodejs.org/en/)

#### Project Resources
- [Trello - Project Management](https://trello.com/b/ovjEMllc/development-tasks)
- [Discord - Communication](https://discordapp.com/channels/481135729297195009/481135729942986753)
